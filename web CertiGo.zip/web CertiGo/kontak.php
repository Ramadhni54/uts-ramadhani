<?php 
$pageTitle = "Kontak";
include 'header.php'; 
?>

<div class="container my-5">
    <h2 class="text-center">Kontak</h2>
    <p class="text-center">Hubungi kami melalui:</p>
    <ul class="list-unstyled text-center">
        <li>Email: <a href="mailto:info@certigo.com">info@certigo.com</a></li>
        <li>Telepon: +62 123 456 789</li>
    </ul>
</div>

<?php include 'footer.php'; ?>
